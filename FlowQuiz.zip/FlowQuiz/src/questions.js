export default [
  {
    text: "Czy lubisz kawę?",
    answers: [
      { text: "Tak", next: 1 },
      { text: "Nie", next: 2 }
    ]
  },
  {
    text: "Super! Wolisz:",
    answers: [
      { text: "Czarną", next: "END" },
      { text: "Z mlekiem", next: "END" }
    ]
  },
  {
    text: "W porządku! Może herbata?",
    answers: [
      { text: "Tak", next: "END" },
      { text: "Nie", next: "END" }
    ]
  }
];
