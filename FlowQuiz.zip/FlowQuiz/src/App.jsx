import { useState } from "react";
import questions from "./questions";

export default function App() {
  const [step, setStep] = useState(0);
  const question = questions[step];

  const handleClick = (nextStep) => {
    if (nextStep === "END") return;
    setStep(nextStep);
  };

  return (
    <div className="max-w-xl mx-auto mt-10 p-6 bg-white shadow-lg rounded">
      <h1 className="text-2xl font-bold mb-4 text-center">FlowQuiz</h1>

      <p className="text-lg font-semibold mb-6">{question.text}</p>

      <div className="flex flex-col gap-3">
        {question.answers.map((a, index) => (
          <button
            key={index}
            onClick={() => handleClick(a.next)}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            {a.text}
          </button>
        ))}
      </div>
    </div>
  );
}
